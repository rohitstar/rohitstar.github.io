-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 17, 2017 at 12:42 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `blog_samples`
--

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE `country` (
  `country_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`country_name`) VALUES
('India'),
('Brazil'),
('China'),
('Nepal'),
('Bhutan'),
('Maldives');

-- --------------------------------------------------------

--
-- Table structure for table `details`
--

CREATE TABLE `details` (
  `id` int(10) NOT NULL auto_increment,
  `fname` varchar(50) NOT NULL,
  `email` varchar(70) NOT NULL,
  `password` varchar(70) NOT NULL,
  `mobile` varchar(14) NOT NULL,
  `age` int(5) NOT NULL,
  `address` varchar(500) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `country` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `details`
--

INSERT INTO `details` (`id`, `fname`, `email`, `password`, `mobile`, `age`, `address`, `gender`, `country`, `state`) VALUES
(2, 'Vipul Sharma', 'vipul01sharma@gmail.com', 'Hello', '9797684796', 25, 'Patoli', 'Male', 'India', 'J&K'),
(3, 'Vipul Sharma', 'raghav012@gmail.com', 'Hello', '8803925473', 20, 'Gandhi Nagar', 'Male', 'India', 'Haryana'),
(4, 'Dharmendra', 'dharmendra@gmail.com', '8900', '8803925473', 22, 'Nanak Nagar', 'Male', '', ''),
(6, '', '', '', '', 0, '', 'Male', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `countryname` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`countryname`, `name`) VALUES
('India', 'Himachal Pradesh'),
('India', 'Punjab'),
('India', 'Sikkim'),
('India', 'Haryana'),
('Nepal', 'Kathmandu'),
('Nepal', 'Kapilvastu');
